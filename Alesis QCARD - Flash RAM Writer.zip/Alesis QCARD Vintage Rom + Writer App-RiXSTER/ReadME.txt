For Alesis QS Rack/Synth Owners
===============================

Please note you need a pcmcia slot on your pc/laptop, your synth/rack will not work!

1.Install the memory card reader demo (sorry I don't have the full version)Its a 30day demo with 5 function limit. Just reinstall if you run out of functions!

2. When asked for a restart say no and turn your pc off and insert your blank 8mb flash card- This must be of the correct type i.e. type1/amd etc. Windows will try and find a driver for it-cancel the wizard!

3. You may have to setup the card manually if its not recognized in the card setup options i.e. flash type1, size 8.00mb, and leave all other options as default, in addition make sure the app is set to the correct pcmcia slot if you have more than 1.

4. Drop the file into the write icon/ or locate it manually and your qcard will be written.

5. Remember turn off your pc after the writing process is finished and remove your new vintage synth qcard!

For creating images the process is similiar upto setup 4, however, instead your qcard will not be recognized at all so manual setup of the card type (in step 3 is essential) press read and a file name and your qcard will be converted to raw data as a .bin file!


I can confirm this works 100% however to cover my own butt I take no repsonsibility for what u do with this info or any damage you do!

RiXSTER