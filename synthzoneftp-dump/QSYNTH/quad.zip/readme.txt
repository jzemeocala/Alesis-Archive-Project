This file, containing 12 Alesis Quadrasynth S4' syx banks,
 downloaded from Philipp Koltsov's studio free patch
collection. www.koltsov.biz



