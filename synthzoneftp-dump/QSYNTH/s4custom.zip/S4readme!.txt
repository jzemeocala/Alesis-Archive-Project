This custom bank contains 128 Alesis S4 patches in MID format, 
created by Philipp Koltsov (http://www.koltsov.biz)

There is a Alesis Calkewalk ins file also (new patches will be finded
in the "Alesis S4 user" definition.

